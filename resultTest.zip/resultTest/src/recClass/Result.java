package recClass;

public class Result {
	public String resultStr;
	public int resultVal;
}
