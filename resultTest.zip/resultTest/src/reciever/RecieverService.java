package reciever;

import java.io.*;
import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

@Path("/reciever")
@Produces("application/json")
public class RecieverService {
	
	@GET
	@Path("/Recieve")
	public Response recieve()
	{
		try {
			String url="http://localhost:8080/resultTest/services/sender/Send";
			WebClient client = WebClient.create(url);
			client.accept("application/json").type("application/json");
			Response response = client.get();
			InputStream inputStream = (InputStream) response.getEntity();
			BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
			StringBuffer sb = new StringBuffer();
			String strTemp = "";
			while (null != (strTemp = br.readLine()))
				sb.append(strTemp);
			String json=sb.toString();
			recClass.Result data=(recClass.Result) new Gson().fromJson(json, recClass.Result.class);
			System.out.println(data.resultStr+" "+data.resultVal);
			return Response.status(200).build();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return Response.status(400).entity("").build();
	}
}
