package sender;

import javax.ws.rs.POST;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

@Path("/sender")
@Produces("application/json")
public class SenderService {
	@GET
	@Path("/Send")
	@Produces(MediaType.APPLICATION_JSON)
	public Response sendResult()
	{
		try {
			recClass.Result data=new recClass.Result();
			data.resultStr="Result";
			data.resultVal=100;
			return Response.status(200).entity(new Gson().toJson(data)).build();
		} catch (JsonSyntaxException e) {
			e.printStackTrace();
		}
		
		return Response.status(400).entity("").build();
	}
}
